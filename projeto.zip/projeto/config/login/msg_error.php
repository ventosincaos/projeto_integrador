<?php if(isset($_GET['erro'])){ ?>

<div class="alert alert-danger" role="alert">
  <p class='font-weight-bold'> Senha ou Usuário invalidos </p>
</div>


</div> 

<?php } ?>