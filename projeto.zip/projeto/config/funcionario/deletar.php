


<?php    
include 'conn.php';
include 'url';

try {
            $idDelete = $_POST['id_cargo_funcionarios'];

            print_r($idDelete);  

            $idDelete = $data["id_funcionarios"];
            $query = "DELETE FROM sysffee.funcionarios WHERE id_cargo_funcionarios =:idDelete";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(":idDelete", $idDelete);
            $stmt->execute();
        } catch (PDOException $e) {
            $erro = $e->getMessage();
            echo $erro;
        }

        ?>