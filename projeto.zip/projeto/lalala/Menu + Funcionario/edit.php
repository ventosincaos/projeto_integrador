<?php
 include_once("header.php");
?>
<?php include_once("backbtn.php"); ?>
<h1>Aqui faz a edição</h1>

<?php
include_once("footer.php");
?>