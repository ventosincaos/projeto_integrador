<?php
 include_once("header.php");
?>
<?php include_once("backbtn.php"); ?>

<h1>Aqui mostra as informações</h1>

<a href="edit.php"><ion-icon name="create-outline"></ion-icon></a>
<a href="#"><ion-icon name="trash-outline"></ion-icon></a> <!--ícone para deletar-->

<?php
include_once("footer.php");
?>