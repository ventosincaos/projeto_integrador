<?php
 include_once("header.php");
?>

<?php include_once("backbtn.php"); ?>
<h1>Aqui a Mari coloca o cadastro de funcionário</h1>

<?php
 include_once("footer.php");
?>
