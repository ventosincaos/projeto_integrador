<?php
 include_once("header.php");
?>
<h3>“When I take you to the Valley,<br> you’ll see the blue hills on the left and the blue hills on the right, <br> the rainbow and the vineyards under the rainbow late in the rainy season,<br>  and maybe you’ll say, “There it is, that’s it!” <br> But I’ll say. “A little farther.” <br> We’ll go on, I hope, and you’ll see the roofs of the little towns and the hillsides yellow <br> with wild oats, a buzzard soaring and a woman singing by the shadows of a creek in the dry season, <br> and maybe you’ll say, “Let’s stop here, this is it!” <br> But I’ll say, “A little farther yet.” We’ll go on, and you’ll hear the quail calling on the mountain by the springs of the river,<br>  and looking back you’ll see the river running downward through the wild hills behind, <br> below, and you’ll say, “Isn’t that the Valley?” <br> And all I will be able to say is “Drink this water of the spring, rest here awhile, <br> we have a long way yet to go and <br> I can’t go without you.”<br>
- Ursula K. Le Guin</h3>

<?php
 include_once("footer.php");
?>
