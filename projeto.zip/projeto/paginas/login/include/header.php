
    
    <header>
        <h2 class="logo">
        <img src="/projeto/img/logo3.png">    
        </h2>
        <nav class="navigation">
            <!-- Não vamos utilizar menu de navegação
                <a href="#">Home</a>
            <a href="#">Sobre</a>
            <a href="#">Serviços</a>
            <a href="#">Contatos</a> 
            <button class="btnLogin-popup">Login</button>//-->
        </nav>
    </header>
    