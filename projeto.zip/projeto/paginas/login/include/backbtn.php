<div id="back-link-container">
<a href="table.php" id="back-link"><ion-icon name="arrow-back-outline"></ion-icon></a>
</div>