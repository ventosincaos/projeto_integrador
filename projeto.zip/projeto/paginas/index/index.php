<?php
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/config/session_manager.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/index/include/head.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/header.php';
?>


<div>
    <h3>Coffee</h3>
    <h3>Café</h3>
    <h3>Café</h3>
    <h3>Kaffee</h3>
    <h3>Caffè</h3>
    <h3>кофе</h3>
    <h3>コーヒー</h3>
</div>

