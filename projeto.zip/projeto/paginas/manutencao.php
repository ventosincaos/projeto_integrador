<?php
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/config/session_manager.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/index/include/head.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/header.php';
?>

<div>
    <h3>Manutenção</h3>
    <h3>Manutenção</h3>
    <h3>Manutenção</h3>
    <h3>Wartung</h3>
    <h3>Manutenzione</h3>
    <h3>Обслуживание</h3>
    <h3>メンテナンス</h3>
</div>