<?php
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/config/session_manager.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/config/funcionario/crud.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/funcionario/include/head.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/header.php';
?>




<main class="table">
    

    <section class="table__header">
        <h1>Funcionários</h1>
     
     
        <div class="adicionar">
           <a href="create.php"> <i> <ion-icon name="add-circle-outline"> </ion-icon> </i> </a> 
        </div>
   
      
  
   
   
   
    </section>
    <section class="table__body">
        <table id="contacts-table">
            <thead>
                <tr>
                    <th> nome </th>
                    <th> sobrenome </th>
                    <th> celular </th>
                    <th> email </th>
                    <th> info </th>
                    <th> delete  </th>
                    <th> update </th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($getAll as $getAl) : ?>
                    <tr>
                        <td><?= $getAl["nome_funcionarios"] ?></td>
                        <td><?= $getAl["sobrenome_funcionarios"] ?></td>
                        <td><?= $getAl["celular_funcionarios"] ?></td>
                        <td><?= $getAl["email_funcionarios"] ?></td>
                        <td><a href="<?= $BASE_URL ?>/show.php?id=<?=$getAl["id"] ?>"><ion-icon class="read" name="book-outline"></ion-icon></a> </td>
                     
<form class="delete-form" action="<?=$BASE_URL?>../../config/funcionario/deletar.php" method="POST">

<input type="hidden" name="id" value="<?=$getAl["id"]?>">
<button type="submit" class="delete-btn">                  
<td><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class=" bi bi-clipboard-x" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M6.146 7.146a.5.5 0 0 1 .708 0L8 8.293l1.146-1.147a.5.5 0 1 1 .708.708L8.707 9l1.147 1.146a.5.5 0 0 1-.708.708L8 9.707l-1.146 1.147a.5.5 0 0 1-.708-.708L7.293 9 6.146 7.854a.5.5 0 0 1 0-.708z"/>
  <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z"/>
  <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z"/>
</svg> </ion-icon> </td> 
</button> 
</form>

<td><a href="<?= $BASE_URL ?>/update.php?id=<?=$getAl["id"] ?>"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-clipboard2-plus" viewBox="0 0 16 16">
  <path d="M9.5 0a.5.5 0 0 1 .5.5.5.5 0 0 0 .5.5.5.5 0 0 1 .5.5V2a.5.5 0 0 1-.5.5h-5A.5.5 0 0 1 5 2v-.5a.5.5 0 0 1 .5-.5.5.5 0 0 0 .5-.5.5.5 0 0 1 .5-.5h3Z"/>
  <path d="M3 2.5a.5.5 0 0 1 .5-.5H4a.5.5 0 0 0 0-1h-.5A1.5 1.5 0 0 0 2 2.5v12A1.5 1.5 0 0 0 3.5 16h9a1.5 1.5 0 0 0 1.5-1.5v-12A1.5 1.5 0 0 0 12.5 1H12a.5.5 0 0 0 0 1h.5a.5.5 0 0 1 .5.5v12a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5v-12Z"/>
  <path d="M8.5 6.5a.5.5 0 0 0-1 0V8H6a.5.5 0 0 0 0 1h1.5v1.5a.5.5 0 0 0 1 0V9H10a.5.5 0 0 0 0-1H8.5V6.5Z"/>
</svg></a> </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>



<?php
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/funcionario/include/footer.php';
?>