<?php
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/config/session_manager.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/config/funcionario/crud.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/funcionario/include/head.php';
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/header.php';
?>


<div class='lado_esquerdo'>
  <div class="perfil">
    <h4><img src="Sarita Limbu.jpg" alt="" > 
      <span>Sommelier de Café profissional </span>
    </h4>

    <button class="edit"><a href="#">Editar</a></button>
  </div>
  <div class="editar">
    <div class="group">
      <h3>Informações pessoais</h3>
      <div class="texfield-group-">
        <h4>Nome<br>
          <span>Jorginho</span>
        </h4>
        <h4>Sobrenome <br>
          <span>Dolfino Fernandes da Silva</span>
        </h4>
      </div>
      <div class="texfield-group-">
        <h4>Telefone <br>
          <span>(66)66666-6666</span>
        </h4>
        <h4>Email <br>
          <span>satanlucifer66@gmail.com</span>
        </h4>
      </div>
      <div class="texfield-group-">
        <h4>Data da Admissão <br>
          <span>30/02/2023</span>
        </h4>
        <h4>Endereço <br>
          <span>Rua da Flores, 30, casa 40</span>
        </h4>
      </div>
      <h4>Descrição do cargo <br>
        <span>Tomar café e dizer se é bom</span>
      </h4>
      <div class="botao">
        <button class="edit-button"><a href="#">Editar</a></button>
        <button class="delete-button"><a href="#">Apagar</a></button>
      </div>
    </div>
  </div>

</div>


<?php
include $_SERVER['DOCUMENT_ROOT'] . '/projeto/paginas/funcionario/include/footer.php';
?>