<?php

include_once("../config/url.php");



?>




<!DOCTYPE html>
<html lang="Pt-Br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/7bf6493d81.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?= $BASE_URL?>/../css/swiper-bundle.min.css">
    <link rel="short icon" href="<?= $BASE_URL?>/../images/logo3.png">
    <link rel="stylesheet" href="<?= $BASE_URL?>/../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?= $BASE_URL?>/../css/style1.css">
   

    <title>Document</title>
</head>



    


