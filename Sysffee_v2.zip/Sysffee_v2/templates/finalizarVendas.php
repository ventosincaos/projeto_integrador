<header>
<div id="myNav" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <div class="overlay-right">
            <div class="form">
                <h2>Finalizar compra</h2>
                <form action="/action_page.php">
                    <label for="fname">Preço total:</label><br>
                    <input type="text" id="fname" name="fname" value="R$"><br>
                    <button type="button" value="Submit" class="Finalizar">Finalizar</button>
                </form>
                </div>
            </div>
            <div class="overlay-left"><!-- div Responsável pela parte ao lado de Finalizar compra --></div>
        </div>
</header>