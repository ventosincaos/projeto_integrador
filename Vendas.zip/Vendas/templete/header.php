


<header>

    <div class="flex">
        <h2 class="logo">logo</h2>
        <nav class="navigation">
            <a href="menu.php">Home</a>
            <a href="table.php">Funcionários</a> <!--Colocar o link de referencia do arquivo no lugar do #-->
            <a href="tableProduct.php">Estoques</a>
            <a href="vendas.php">Vendas</a>
        </nav>
    </div>

</header>