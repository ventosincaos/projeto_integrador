   

<?php
   include_once('conection.php');



    $data = $_POST;

switch($data['type']){
 case 1:
    try{ 
    
   $nome = $data['nome'];
   $sobre = $data['sobrenome'];
   $cpf = $data['cpf'];
   $rg = $data["rg"];
   $orgao_emissor = $data['orgao_emissor'];
   $email = $data['email'];
   $endereco = $data['endereco'];
   $telefone = $data['telefone'];
   $celular = $data['celular'];
   $data_admissao = $data['data_admissao'];
   $cargo = $data['cargo'];
   $senha = $data['senha'];

    $query = "INSERT INTO 
    funcionario(nome, sobrenome, 
    cpf, rg, orgao_emissor, 
    email, endereco, telefone,
     celular, data_admissao,
      cargo, senha)VALUES(
     :nome, :sobrenome, :cpf,
     :rg ,:orgao_emissor,
     :email, :endereco, 
     :telefone, :celular, 
     :data_admissao, 
     :cargo, :senha )";

    $stmt = $conn->prepare($query);
    $stmt -> bindParam(":nome", $nome);
    $stmt -> bindParam(":sobrenome", $sobrenome);
    $stmt -> bindParam(":cpf", $cpf);
    $stmt -> bindParam(":rg", $rg);
    $stmt -> bindParam(":orgao_emissor", $orgao_emissor);
    $stmt -> bindParam(":email", $email);
    $stmt -> bindParam(":endereco", $endereco);
    $stmt -> bindParam(":telefone", $telefone);
    $stmt -> bindParam(":celular", $celular);
    $stmt -> bindParam(":data_admissao", $data_admissao);
    $stmt -> bindParam(":cargo", $cargo);
    $stmt -> bindParam(":senha", $senha);
    $stmt -> execute();

    echo "cadastrado";
}
catch(PDOException $e){
    $erro = $e -> getMessage();
    echo $error;
}
     break;

case 2:

 try{
    $idPost = $data['id'];
    $nome = $data['nome'];
    $sobre = $data['sobrenome'];
    $cpf = $data['cpf'];
    $rg = $data["rg"];
    $orgao_emissor = $data['orgao_emissor'];
    $email = $data['email'];
    $endereco = $data['endereco'];
    $telefone = $data['telefone'];
    $celular = $data['celular'];
    $data_admissao = $data['data_admissao'];
    $cargo = $data['cargo'];
    $senha = $data['senha'];

$query= "UPDATE exemplo.funcionario SET
nome=:nome,
sobrenome=:sobrenome,
cpf=:cpf,
rg=:rg,
orgao_emissor =:orgao_emissor,
email =:email,
endereco = :endereco,
telefone = :telefone,
celular = :celular,
data_admissao = :data_admissao,
cargo = :cargo,
senha = :senha
WHERE id = :idPost";

    $stmt= $conn->prepare($query);
    $stmt->bindParam(":idPost", $idPost);
    $stmt -> bindParam(":nome", $nome);
    $stmt -> bindParam(":sobrenome", $sobrenome);
    $stmt -> bindParam(":cpf", $cpf);
    $stmt -> bindParam(":rg", $rg);
    $stmt -> bindParam(":orgao_emissor", $orgao_emissor);
    $stmt -> bindParam(":email", $email);
    $stmt -> bindParam(":endereco", $endereco);
    $stmt -> bindParam(":telefone", $telefone);
    $stmt -> bindParam(":celular", $celular);
    $stmt -> bindParam(":data_admissao", $data_admissao);
    $stmt -> bindParam(":cargo", $cargo);
    $stmt -> bindParam(":senha", $senha);

$stmt->execute();

echo "deu certo";

} catch(PDOException $e){
$erro= $e->getMessage();
echo $erro;
}

    
case 3:
    try{
$idDelete = $data["id"];
$query = "DELETE FROM exemplo.funcionario WHERE id=:idDelete";
$stmt = $conn->prepare($query);
$stmt->bindParam(":idDelete", $idDelete);
$stmt->execute();
} catch(PDOException $e){
$erro= $e->getMessage();
echo $erro;
}
    
default:


$query= "SELECT * FROM exemplo.funcionario";
$stmt= $conn->prepare($query);
$stmt->execute();
$getDatas = $stmt->fetch();


$query= "SELECT * FROM exemplo.funcionario";
$stmt= $conn->prepare($query);
$stmt->execute();
$getAll = [];
$getAll = $stmt->fetchAll();// retorna todas as linhas para a variavel


break;

   
    }



?>