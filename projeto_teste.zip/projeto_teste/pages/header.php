<?php include_once("../config/conection.php"); ?>

<html lang="pt-br">
    <head>
    <meta charset="utf-8">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width-device-width, inicial-scale=1.0">
    <title>Site com login e registro</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
     <body>
        
     <header>

<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <h2 class="logo"><img src="../img/logo3.png"></h2>
  </div>
</nav>
        </nav>
    </header>