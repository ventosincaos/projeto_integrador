<?php
$user = 'root';
$pass = '';
$database = 'teste1';
$host = 'localhost';

$conexao = new mysqli($host, $user, $pass, $database);
/* utilizar esse comando para testar a conexão
if($conexao){
    echo "conectado com sucesso";
}
else {
    echo "Error ao conectar";
}
*/


?>