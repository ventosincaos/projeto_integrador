<?php 
include_once('head.php');
?>

<h1> Login correto! más página em manutenção </h1>

<?php 
include_once('footer.php');
?>