
<?php 

      include_once('head.php');
      include_once('header.php'); 
      
?>




  
    <canvas id="lamp-anim" class="lamp-anim" width="100%" height="100%"></canvas>
    <div class="wrapper">
        <div class="span icon-close"><ion-icon name="close"></ion-icon></div>
       <div class="form-box login">
        <h2>Login</h2>
        
        <form action="../config/logar.php" method="POST">
            <div class="input-box">
                <span class="icon"><ion-icon name="person"></ion-icon></ion-icon></span>
                <input type="usuario" name="usuario" required>
                <label>Usuário</label>
            </div>
            <div class="input-box">
                <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                <input type="password" name="senha" required>
                <label> Senha</label>
            </div>
            <div class="remember-forget">
                <label ><input type="checkbox"> Lembrar-se</label>
               <!-- trocar esse esqueceu a senha para um novo embaixo do botão
                <a href="#">Esqueceu a senha</>-->
            </div>
            
            <button type="submit" class="btn">Login</button>
           
            <div class="login-register">
            <!--Apesar da class ter register, sua função foi mudada para recuperação de senha, sendo a página de
            registro feita em outro arquivo-->
              
            <p>Esqueceu a senha? <a href="#" class="register-link"> Recupere </a></p>
          
            <?php 
               // chama recuperar senha
             include_once('../config/msg_error.php');  // chama mensagem de erro caso o login esteja errado  ?>      
            </div>


        </form>
          <?php include_once('rec_senha.php'); ?>
    
    </div>

   
   
        
    
    
    </div>
    
    
  <?php include_once('footer.php'); // coloquei os scripts para carregar no footer.php para que não precisamos copiar muito o  código?>

