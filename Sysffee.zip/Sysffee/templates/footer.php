

<script src="<?= $BASE_URL?>/../js/script1.js"></script>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"> </script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"> </script>

<!-- Swiper JS -->

<script src="../js/swiper-bundle.min.js"></script>
<script src="https://kit.fontawesome.com/7bf6493d81.js" crossorigin="anonymous"></script>

<script src="<?= $BASE_URL?>/../js/script1.js"></script>
<!-- JavaScript -->
<script src="../js/script.js"></script>
<script src="../js/scriptNav.js"></script>

</body>
</html>

